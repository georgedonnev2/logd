#ifndef REGISTER_CODE_H
#define REGISTER_CODE_H

#define REGISTER_CODE "DIA4-PUH9"

#endif
