
#include "register_code.h"
#include "Register_Callback.h"

String registerCodeCallback(){return REGISTER_CODE;}  