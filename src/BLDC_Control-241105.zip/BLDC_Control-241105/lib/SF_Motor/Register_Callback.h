#ifndef _REGISTER_CALLBACK_h
#define _REGISTER_CALLBACK_h

#include <Arduino.h>
#include "register_code.h"


String registerCodeCallback(); 


#endif